package com.distancehud.client;

import com.distancehud.HudConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.gui.overlay.ForgeGui;

import java.util.Locale;

public final class DistanceHud {
    /** How far (in blocks) the crosshair ray looks for a block. */
    public static final double MAX_RANGE = 128.0;

    private DistanceHud() {
    }

    public static String format(double distance) {
        return String.format(Locale.ROOT, "%.1f m", distance);
    }

    /** Overlay callback (signature matches IGuiOverlay). */
    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int width, int height) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.options.hideGui) {
            return;
        }

        HitResult hit = player.pick(MAX_RANGE, partialTick, false);
        if (hit.getType() != HitResult.Type.BLOCK) {
            return;
        }

        BlockPos pos = ((BlockHitResult) hit).getBlockPos();
        double distance = player.getEyePosition(partialTick).distanceTo(Vec3.atCenterOf(pos));

        drawCentered(g, mc.font, format(distance),
                HudConfig.POS_X.get() * width,
                HudConfig.POS_Y.get() * height);
    }

    /** Draws plain white text centered on (cx, cy) in GUI pixels. */
    public static void drawCentered(GuiGraphics g, Font font, String text, double cx, double cy) {
        int x = (int) Math.round(cx - font.width(text) / 2.0);
        int y = (int) Math.round(cy - font.lineHeight / 2.0);
        g.drawString(font, text, x, y, 0xFFFFFFFF, true);
    }
}
