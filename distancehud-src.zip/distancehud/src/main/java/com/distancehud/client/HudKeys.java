package com.distancehud.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

public final class HudKeys {
    public static final KeyMapping OPEN_EDITOR = new KeyMapping(
            "key.distancehud.editor",
            KeyConflictContext.IN_GAME,
            InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_O,
            "key.categories.distancehud");

    private HudKeys() {
    }
}
