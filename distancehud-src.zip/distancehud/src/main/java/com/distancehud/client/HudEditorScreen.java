package com.distancehud.client;

import com.distancehud.HudConfig;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.util.Mth;

/**
 * Empty screen with a sample of the HUD text.
 * Hold LMB on the text and drag it anywhere; ESC (or the editor key again) saves and closes.
 */
public class HudEditorScreen extends Screen {
    private static final String SAMPLE = "5.4 m";

    // Text center as a fraction of the screen size.
    private double fx;
    private double fy;

    private boolean dragging;
    private double grabOffsetX;
    private double grabOffsetY;

    public HudEditorScreen() {
        super(Component.empty());
        this.fx = HudConfig.POS_X.get();
        this.fy = HudConfig.POS_Y.get();
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        g.drawCenteredString(this.font, "Drag the text with the left mouse button. Press ESC to save.",
                this.width / 2, 8, 0xFF808080);
        DistanceHud.drawCentered(g, this.font, SAMPLE, fx * this.width, fy * this.height);
        super.render(g, mouseX, mouseY, partialTick);
    }

    private boolean isOverText(double mx, double my) {
        double halfW = Math.max(this.font.width(SAMPLE) / 2.0 + 6.0, 16.0);
        double halfH = this.font.lineHeight / 2.0 + 6.0;
        return Math.abs(mx - fx * this.width) <= halfW && Math.abs(my - fy * this.height) <= halfH;
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0 && isOverText(mouseX, mouseY)) {
            dragging = true;
            grabOffsetX = mouseX - fx * this.width;
            grabOffsetY = mouseY - fy * this.height;
            return true;
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (dragging && button == 0) {
            double cx = Mth.clamp(mouseX - grabOffsetX, 0.0, this.width);
            double cy = Mth.clamp(mouseY - grabOffsetY, 0.0, this.height);
            fx = cx / this.width;
            fy = cy / this.height;
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }

    @Override
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (button == 0 && dragging) {
            dragging = false;
            return true;
        }
        return super.mouseReleased(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (HudKeys.OPEN_EDITOR.matches(keyCode, scanCode)) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    /** Called on any way of closing the screen (ESC included) - saves the position. */
    @Override
    public void removed() {
        HudConfig.save(fx, fy);
        super.removed();
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
