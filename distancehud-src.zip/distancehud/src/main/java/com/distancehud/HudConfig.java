package com.distancehud;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Stores the HUD text position as fractions of the screen size (0..1),
 * so it stays in the same relative place at any resolution / GUI scale.
 * File: config/distancehud-client.toml
 */
public final class HudConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue POS_X;
    public static final ForgeConfigSpec.DoubleValue POS_Y;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("hud");
        POS_X = b.comment("Horizontal center of the text, 0.0 = left edge, 1.0 = right edge")
                .defineInRange("posX", 0.5, 0.0, 1.0);
        POS_Y = b.comment("Vertical center of the text, 0.0 = top edge, 1.0 = bottom edge")
                .defineInRange("posY", 0.55, 0.0, 1.0);
        b.pop();
        SPEC = b.build();
    }

    private HudConfig() {
    }

    public static void save(double x, double y) {
        POS_X.set(Math.max(0.0, Math.min(1.0, x)));
        POS_Y.set(Math.max(0.0, Math.min(1.0, y)));
        SPEC.save();
    }
}
