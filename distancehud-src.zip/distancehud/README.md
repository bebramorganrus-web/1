# Distance HUD (Minecraft 1.20.1, Forge 47.3.0)

Показывает расстояние от глаз игрока до центра блока под прицелом: `5.4 m`.
Клавиша `O` открывает редактор: зажмите ЛКМ на тексте, перетащите куда угодно, `ESC` сохраняет позицию.
Позиция хранится в `config/distancehud-client.toml` (доли экрана 0..1, не зависит от разрешения).

## Сборка

Нужен JDK 17 и Gradle 8.1.1 (`gradle wrapper --gradle-version 8.1.1` создаст gradlew).

    gradle build

Готовый файл: `build/libs/distancehud-1.0.0.jar` (кладите в папку `mods`).

Без локальной установки: залейте папку в репозиторий GitHub, вкладка Actions -> build ->
артефакт `distancehud-jar` (workflow уже лежит в `.github/workflows/build.yml`).
